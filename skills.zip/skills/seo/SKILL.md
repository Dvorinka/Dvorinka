---
name: seo
description: Comprehensive SEO analysis for websites and businesses. Audit technical SEO, content quality (E-E-A-T), schema markup, sitemaps, Core Web Vitals with INP, image optimization, and AI search readiness for AI Overviews, ChatGPT, and Perplexity. Use when requests mention SEO, audit, schema, Core Web Vitals, sitemap, technical SEO, content quality, E-E-A-T, GEO, AI crawler access, llms.txt, programmatic SEO, competitor pages, or hreflang.
---

# SEO

Perform comprehensive SEO analysis across SaaS, local services, e-commerce, publishers, agencies, and mixed business models. Run full audits or focused deep-dives, then return prioritized actions with clear severity.

## Command Map

| Command | Action |
|---------|--------|
| `/seo audit <url>` | Run full website audit with parallel workstreams |
| `/seo page <url>` | Run deep single-page analysis |
| `/seo sitemap <url or generate>` | Audit or generate XML sitemap strategy |
| `/seo schema <url>` | Detect, validate, and generate schema |
| `/seo images <url>` | Audit image SEO and media delivery |
| `/seo technical <url>` | Audit crawlability/indexability/infra |
| `/seo content <url>` | Evaluate E-E-A-T and content quality |
| `/seo geo <url>` | Audit AI Overviews and GEO readiness |
| `/seo plan <business-type>` | Produce strategic SEO roadmap |
| `/seo programmatic [url|plan]` | Analyze programmatic SEO viability |
| `/seo competitor-pages [url|generate]` | Build competitor comparison page plan |
| `/seo hreflang [url]` | Audit hreflang and i18n SEO coverage |

## Full Audit Workflow

For `/seo audit <url>`, execute this order:
1. Detect business type from homepage signals.
2. Run six tracks in parallel when possible:
   - Technical SEO
   - Content quality
   - Schema
   - Sitemap
   - Performance
   - Visual/mobile UX
3. Compute unified SEO Health Score.
4. Return findings sorted by priority:
   - Critical: fix now
   - High: fix within 1 week
   - Medium: fix within 1 month
   - Low: backlog
5. Provide a concrete action plan with expected impact.

## Business Type Detection

Infer primary business type using homepage and IA signals:
- SaaS: `/pricing`, `/features`, `/integrations`, `/docs`, "free trial", "sign up"
- Local service: address, phone, map embed, service areas, city modifiers
- E-commerce: `/products`, `/collections`, cart flows, Product schema
- Publisher: `/blog`, `/articles`, author pages, publish/update dates
- Agency: `/case-studies`, `/portfolio`, client logos, industry pages

If mixed signals exist, mark "hybrid" and tailor recommendations per page cluster.

## Quality Gates

Apply these non-negotiable rules:
- Warn at 30+ location pages and require at least 60% unique content per page.
- Hard stop at 50+ location pages unless user explicitly justifies scale and differentiation plan.
- Never recommend HowTo schema as an SEO lever.
- Recommend FAQ schema only for government and healthcare websites.
- Use INP for responsiveness; do not use FID in recommendations.

Load `references/quality-gates.md` before auditing large template sets.

## Scoring Model

Use weighted aggregate:

| Category | Weight |
|----------|--------|
| Technical SEO | 25% |
| Content Quality | 25% |
| On-Page SEO | 20% |
| Schema / Structured Data | 10% |
| Performance (CWV) | 10% |
| Images | 5% |
| AI Search Readiness | 5% |

Round final score to nearest integer and explain largest negative contributors.

## Reference Loading Rules

Do not load every reference at startup. Load only what the task needs:
- `references/cwv-thresholds.md`: CWV threshold checks and measurement caveats
- `references/schema-types.md`: supported/deprecated schema and eligibility notes
- `references/eeat-framework.md`: E-E-A-T evaluation rubric
- `references/quality-gates.md`: thin content and scaled-page gating rules

## Sub-Skills and Delegation

Use these capability labels in reports:
1. `seo-audit`
2. `seo-page`
3. `seo-technical`
4. `seo-content`
5. `seo-schema`
6. `seo-images`
7. `seo-sitemap`
8. `seo-geo`
9. `seo-plan`
10. `seo-programmatic`
11. `seo-competitor-pages`
12. `seo-hreflang`

When splitting a full audit, delegate these tracks in parallel:
- `seo-technical`
- `seo-content`
- `seo-schema`
- `seo-sitemap`
- `seo-performance`
- `seo-visual`
