# Content Quality Gates

Use these gates before recommending scale, templates, or programmatic rollout.

## Thin Content Thresholds

Apply minimum effective content targets by page type:

| Page Type | Minimum Body Content | Minimum Unique Content | Notes |
|-----------|----------------------|------------------------|-------|
| Homepage | 500 words | 70% | Differentiate value proposition and audience |
| Service page | 700 words | 70% | Include process, proof, and FAQs |
| Location page | 600 words | 60% | Require city-specific proof and context |
| Product category | 350 words | 65% | Add buyer guidance, not filler |
| Product detail | 250 words | 80% | Unique specs, differentiators, and use cases |
| Blog/article | 900 words | 75% | Include original insights and references |
| Competitor comparison | 1000 words | 80% | Require side-by-side evidence |

If intent is fully satisfied with less copy, allow exception only with strong evidence (high engagement and conversion outcomes).

## Scaled Location Page Rules

- Warning threshold: 30+ location pages.
- Hard stop threshold: 50+ location pages.
- Require at least 60% unique content per location page.
- Require at least 3 localized proof elements per page:
  - local testimonials/case studies
  - location-specific service details
  - local team, office, or coverage details

At hard stop, ask for explicit user justification before proceeding with large-scale rollout.

## Programmatic SEO Gates

Before recommending programmatic generation:
1. Confirm variable set produces real informational differences.
2. Confirm pages can include unique utility (data, tools, comparisons, or local proof).
3. Reject if output would only swap tokens (city/product names) in near-identical copy.
4. Define canonicalization and indexability strategy up front.

## Duplication Risk Bands

| Similarity Between Pages | Risk Level | Action |
|--------------------------|------------|--------|
| < 40% shared text | Low | Proceed |
| 40% to 60% shared text | Medium | Add differentiators before publishing |
| > 60% shared text | High | Block rollout until content model is redesigned |

## Schema Content Policy

- Do not recommend HowTo schema as a growth recommendation.
- Limit FAQ schema recommendations to government and healthcare sites.
- Ensure structured data mirrors visible page content.

## Gate Outcome Labels

Return one of:
- `pass`: Meets thresholds
- `pass_with_risk`: Can ship with documented constraints
- `fail`: Block and redesign content strategy

Always include concrete remediation steps for `pass_with_risk` and `fail`.
