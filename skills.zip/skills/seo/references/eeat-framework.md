# E-E-A-T Evaluation Framework

Use this rubric to evaluate content quality for competitive queries.

## Dimensions

Score each dimension from 0 to 5:

| Dimension | What to Check |
|-----------|---------------|
| Experience | First-hand evidence, practical examples, real usage context |
| Expertise | Subject competence, technical accuracy, depth, specialist language used correctly |
| Authoritativeness | Reputation signals, citations, recognized brand/person entities |
| Trustworthiness | Accuracy, transparency, policy clarity, editorial rigor, safety disclosures |

## Query Stakes Classification

Classify intent before scoring:

- YMYL-high: finance, health, legal, safety
- Commercial-high: high-ticket buying decisions
- Informational-competitive: dense SERP competition with strong entities
- Informational-low: low-risk, basic educational intent

Raise trust requirements for higher-stakes intents.

## Evidence Checklist

Review per template:

1. Authorship clarity:
   - named author
   - credentials or role
   - updated timestamp
2. Source quality:
   - primary sources cited
   - external corroboration
   - quote/context integrity
3. Editorial quality:
   - original analysis (not paraphrased commodity text)
   - internal consistency across pages
   - clear claims with evidence
4. Trust assets:
   - about page and editorial policy
   - contact and business identity
   - privacy and terms links
5. User value:
   - intent match
   - completeness
   - actionable depth

## Risk Flags

Flag as high risk when you find:
- anonymous or credential-free expert claims on high-stakes pages
- copied or near-duplicate boilerplate across key landing pages
- medical/financial/legal recommendations without sourcing
- exaggerated claims without verifiable proof

## Scoring Output Format

Return:
1. Overall content quality score (0-100)
2. Per-dimension scores mapped from rubric
3. Top 3 trust risks
4. Fastest high-impact remediation actions

## Remediation Patterns

- Add expert-reviewed blocks with named reviewers on high-stakes pages.
- Replace generic intros with first-hand evidence and data-backed claims.
- Add citation discipline: primary sources first, then secondary context.
- Standardize author bylines, update dates, and revision ownership.
