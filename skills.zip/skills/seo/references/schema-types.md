# Schema Type Guidance

Prefer JSON-LD. Validate syntax and eligibility before recommending implementation.

## Recommended by Site Type

| Site Type | Primary Schema | Secondary Schema |
|-----------|----------------|------------------|
| SaaS | `SoftwareApplication`, `Organization` | `Product`, `BreadcrumbList`, `WebSite` |
| Local service | `LocalBusiness` (or subtype), `Organization` | `Service`, `Review`, `BreadcrumbList` |
| E-commerce | `Product`, `Offer`, `AggregateRating` | `Organization`, `BreadcrumbList`, `ItemList` |
| Publisher | `Article`/`NewsArticle`, `Person`, `Organization` | `BreadcrumbList`, `ImageObject` |
| Agency | `Organization`, `Service` | `FAQPage` (restricted use), `BreadcrumbList` |

## Important Eligibility Notes

- Do not recommend `HowTo` as an SEO growth tactic.
- Recommend `FAQPage` only for government and healthcare use cases.
- Keep markup aligned with visible on-page content.
- Prefer one coherent graph over fragmented duplicate blocks.

## Global Baseline Types

Implement these where applicable:
- `Organization` with logo, URL, sameAs
- `WebSite` with `SearchAction` if site search exists
- `BreadcrumbList` on hierarchical pages

## E-commerce Essentials

For product pages, include:
- `name`
- `description`
- `image`
- `sku` or `gtin` when available
- `brand`
- `offers` (`price`, `priceCurrency`, `availability`, `url`)
- `aggregateRating` only when genuine ratings exist

## Publisher Essentials

For article pages, include:
- `headline`
- `datePublished`
- `dateModified`
- `author`
- `publisher`
- `mainEntityOfPage`
- `image`

## Validation Workflow

1. Detect current schema blocks and type coverage.
2. Validate syntax and required fields.
3. Check content parity (structured data must match rendered content).
4. Remove conflicting or duplicate nodes.
5. Prioritize schema by impact:
   - Critical: invalid structured data causing parsing failures
   - High: missing core schema for primary page type
   - Medium: missing enrichment fields
   - Low: optional graph enhancements
