# Core Web Vitals Thresholds (INP-era)

Use field data first (CrUX/RUM), then lab data for diagnosis.

## Primary Metrics

| Metric | Good | Needs Improvement | Poor |
|--------|------|-------------------|------|
| LCP | <= 2.5s | > 2.5s and <= 4.0s | > 4.0s |
| INP | <= 200ms | > 200ms and <= 500ms | > 500ms |
| CLS | <= 0.10 | > 0.10 and <= 0.25 | > 0.25 |

## Supporting Diagnostics

Use these as diagnostic hints, not ranking stand-ins:

| Metric | Suggested Target |
|--------|------------------|
| TTFB | <= 0.8s |
| FCP | <= 1.8s |
| Total Blocking Time (lab) | <= 200ms |
| Main-thread long tasks | < 50ms each where possible |

## Measurement Hierarchy

1. Field data source priority:
   - CrUX (origin + URL level if available)
   - First-party RUM
2. Lab data source priority:
   - PageSpeed Insights lab profile
   - Lighthouse (mobile + throttled) for reproducible debugging

## Audit Instructions

1. Compare mobile first, then desktop.
2. Classify each page template by CWV risk:
   - Critical: poor in any primary metric on key template
   - High: needs improvement on key conversion template
   - Medium: issue on secondary templates
3. Map root causes:
   - LCP: render-blocking CSS/JS, slow HTML, heavy hero image
   - INP: long JS tasks, expensive handlers, third-party script contention
   - CLS: unsized media, ad/embed shifts, late DOM injections
4. Propose one quick win and one structural fix per failing metric.

## Rules

- Always use INP. Do not reference FID as a current optimization target.
- Avoid over-claiming from synthetic tests alone.
- If field data is unavailable, clearly label findings as provisional.
